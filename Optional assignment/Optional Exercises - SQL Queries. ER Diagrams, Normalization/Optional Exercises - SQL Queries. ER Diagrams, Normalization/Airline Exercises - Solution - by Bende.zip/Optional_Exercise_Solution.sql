CREATE TABLE Person
(
    firstname VARCHAR(50) NOT NULL,
    lastname  VARCHAR(50) NOT NULL,
    phone     VARCHAR(20),
    email     VARCHAR(50) NOT NULL
);

CREATE TABLE Customer
(
    id SERIAL PRIMARY KEY
) INHERITS (Person);

CREATE TABLE Employee
(
    id         SERIAL PRIMARY KEY,
    work_phone VARCHAR(50) NOT NULL,
    work_email VARCHAR(50) NOT NULL
) INHERITS (Person);


CREATE TABLE Company
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(50)
);
CREATE TABLE Flight
(
    id              SERIAL PRIMARY KEY,
    origin          VARCHAR(50) NOT NULL,
    destination     VARCHAR(50) NOT NULL,
    arrival_time    TIMESTAMP   NOT NULL,
    departure_time  TIMESTAMP   NOT NULL,
    total_seats     INTEGER     NOT NULL,
    seats_available INTEGER     NOT NULL
);
CREATE TABLE Ticket
(
    id          SERIAL PRIMARY KEY,
    price       REAL NOT NULL,
    seat_nr     VARCHAR(10),
    customer_id INTEGER REFERENCES Customer (id),
    flight_id   INTEGER REFERENCES Flight (id),
    UNIQUE (flight_id, seat_nr)
);

CREATE TABLE Role
(
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(20) NOT NULL,
    description VARCHAR
);

CREATE TABLE Works_For
(
    employee_id INTEGER REFERENCES Employee (id),
    company_id  INTEGER REFERENCES Company (id),
    role_id     INTEGER REFERENCES Role (id),
    PRIMARY KEY (employee_id, company_id, role_id)
);

CREATE TABLE Company_Provides_Flights
(
    company_id INTEGER REFERENCES Company (id),
    flight_id  INTEGER UNIQUE REFERENCES Flight (id),
    PRIMARY KEY (company_id, flight_id)
);

CREATE TABLE Employee_Assigned_To_Flight
(
    employee_id INTEGER REFERENCES Employee (id),
    flight_id   INTEGER REFERENCES Flight (id),
    PRIMARY KEY (employee_id, flight_id)
);

INSERT INTO Customer (firstname, lastname, phone, email)
VALUES ('Sten', 'Adamsen', '12345678', 'sten_a420@hotmail.com'),
       ('Yuval', 'Harari', '123456234', 'y_harari@hotmail.com'),
       ('Victor', 'Bramsen', '1323456234', 'vicbram@gmail.com');

SELECT *
FROM Customer;

INSERT INTO Employee(firstname, lastname, email, work_phone, work_email)
VALUES ('Christian', 'Fallowe', 'chrfall@hotmail.com', '74554687', 'chfa24@company.com'),
       ('Normen', 'Matsen', 'noma18@hotmail.com', '234567', 'noma12@company.com'),
       ('Nils', 'Beck', 'nille69@hotmail.com', '45683568', 'nibe13@company.com');

SELECT *
FROM Employee;

INSERT INTO Flight(origin, destination, arrival_time, departure_time, total_seats, seats_available)
VALUES ('LAX', 'AMS', timestamp '2020-06-07 20:38:40', timestamp '2020-06-08 10:38:40', 120, 23),
       ('CPH', 'CDG', timestamp '2020-06-02 21:21:21', timestamp '2020-06-02 23:23:40', 120, 23), --Copenhagen to Paris
       ('PRG', 'VIE', timestamp '2019-03-17 12:45:30', timestamp '2019-03-17 13:25:59', 120, 23);

SELECT *
FROM Flight;

-------------------------------------------------------------------------------------------------------
-- EXERCISE 2

INSERT INTO Ticket(price, seat_nr, customer_id, flight_id)
VALUES (90.50, '62C', 1, 2),
       (120.50, '12B', 1, 1),
       (20.50, '98F', 3, 1);

SELECT *
FROM Ticket;

INSERT INTO Company(name)
VALUES ('AirBeam');

SELECT *
FROM Company;

INSERT INTO Role(name)
VALUES ('Cook'),
       ('Stewardess'),
       ('Pilot');

SELECT *
FROM Role;

INSERT INTO Works_For(employee_id, company_id, role_id)
VALUES (1, 1, 3),
       (2, 1, 2),
       (3, 1, 1),
       (2, 1, 1);

SELECT *
FROM Works_For;

INSERT INTO Employee_Assigned_To_Flight(employee_id, flight_id)
VALUES (1, 1),
       (1, 2),
       (2, 3),
       (3, 2),
       (2, 1);

SELECT *
FROM Employee_Assigned_To_Flight;

INSERT INTO Company_Provides_Flights(company_id, flight_id)
VALUES (1, 1),
       (1, 2),
       (1, 3);

SELECT *
FROM Company_Provides_Flights;

-- Make a query which gets a specific employee based on their phone number
SELECT firstname, lastname, work_phone
FROM Employee
WHERE work_phone = '74554687';

-- Make a query which gets a customer based on their ID
SELECT id, firstname, lastname
FROM Customer
WHERE id = 1;

--Make a query which gets an employee based on their email
SELECT firstname, lastname, work_email
FROM Employee
WHERE work_email = 'noma12@company.com';

--Make a query which gets all customers with a Gmail email (e.g. all customers where the
-- email ends with gmail.com)
SELECT firstname, lastname, email
FROM Customer
WHERE LOWER(email) LIKE '%gmail.com'; -- converting to lowercase, before checking


-- Make a query which gets all the customers for a specific flight
SELECT firstname, lastname
FROM Customer
WHERE Customer.id IN
      (
          SELECT customer_id
          FROM Ticket,
               Flight
          WHERE Ticket.flight_id = 2
      );

-- Make a query which gets all the flights that travels to Amsterdam (Netherlands) between 1.
-- June 2020 to 10. June 2020
SELECT destination
FROM Flight
WHERE departure_time between '2020-06-01' and '2020-06-10'
  and Flight.destination = 'AMS';


-- Make a query which get all the customers who have booked a flight to Paris (France) on 2.
-- June 2020
SELECT firstname, lastname
FROM Customer
WHERE Customer.id IN
      (
          SELECT customer_id
          FROM Ticket,
               Flight
          WHERE Ticket.flight_id = Flight.id
            AND Flight.destination = 'CDG'
            AND Flight.departure_time = '2020-06-02'
      );

--------------------------------------------------------------------------------------------
-- EXERCISE 3

-- Create indexes to make the database faster
CREATE INDEX flight_destination_idx ON Flight(destination);
CREATE INDEX customer_seat_nr_idx ON Ticket(seat_nr);


----------------------------------------------------------------------------------------------
-- EXERCISE 4

-- Create a Trigger which, whenever a ticket is sold, updates the number of seats left on a
-- flight

CREATE OR REPLACE PROCEDURE update_available_seats_on_flight(checked_flight_id INTEGER)
AS $$
DECLARE
    seats_taken integer := 0;
BEGIN
    SELECT COUNT(DISTINCT seat_nr) INTO seats_taken
    FROM Ticket
    WHERE Ticket.flight_id = checked_flight_id;
    UPDATE Flight SET seats_available = total_seats - seats_taken WHERE id = checked_flight_id;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE update_all_available_seats_on_flight()
AS $$
DECLARE
    flights CURSOR FOR SELECT DISTINCT(id) AS id FROM Flight;
BEGIN
    FOR flight in flights LOOP
        CALL update_available_seats_on_flight(flight.id);
    END LOOP;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_all_available_seats_on_flight_trigger()
    RETURNS TRIGGER
AS $$
BEGIN
    CALL update_all_available_seats_on_flight();
    RETURN NEW;
END; $$
LANGUAGE plpgsql;

CREATE TRIGGER update_available_seats_trigger
    AFTER INSERT OR DELETE ON Ticket
    EXECUTE PROCEDURE update_all_available_seats_on_flight_trigger();





